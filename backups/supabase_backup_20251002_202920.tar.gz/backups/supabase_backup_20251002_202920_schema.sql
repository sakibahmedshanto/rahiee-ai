-- =====================================================
-- SUPABASE DATABASE COMPLETE BACKUP DUMP
-- =====================================================
-- Project: Rahiee AI (epigntookxmheaoreqjw)
-- Generated: October 2, 2025
-- Database: PostgreSQL 17.4
-- 
-- This file contains:
-- 1. Table schemas
-- 2. RLS policies  
-- 3. Database functions
-- 4. Triggers
-- 5. Data export instructions
--
-- RESTORE INSTRUCTIONS:
-- 1. Create a new Supabase project
-- 2. Run this SQL in the SQL Editor
-- 3. Then export/import data using the data dump commands below
-- =====================================================

-- =====================================================
-- DISABLE TRIGGERS AND RLS FOR RESTORATION
-- =====================================================
SET session_replication_role = replica;

-- =====================================================
-- TABLE: my_users
-- =====================================================
CREATE TABLE IF NOT EXISTS public.my_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id VARCHAR UNIQUE NOT NULL,
    username VARCHAR NOT NULL,
    email VARCHAR UNIQUE NOT NULL,
    phone VARCHAR,
    user_img TEXT,
    user_device_token TEXT,
    full_name VARCHAR NOT NULL,
    department VARCHAR DEFAULT 'General',
    position VARCHAR DEFAULT 'Employee',
    user_role VARCHAR DEFAULT 'employee' CHECK (user_role IN ('employee', 'admin', 'ceo', 'manager')),
    is_active BOOLEAN DEFAULT true,
    created_on TIMESTAMPTZ DEFAULT NOW(),
    work_location VARCHAR,
    shift_type VARCHAR CHECK (shift_type IN ('morning', 'evening', 'night', 'flexible')),
    supervisor_id VARCHAR,
    salary_rate NUMERIC,
    emergency_contact VARCHAR,
    emergency_phone VARCHAR,
    biometric_enabled BOOLEAN DEFAULT false,
    preferred_language VARCHAR DEFAULT 'en',
    notifications_enabled BOOLEAN DEFAULT true,
    total_coverage_given INTEGER DEFAULT 0,
    total_coverage_received INTEGER DEFAULT 0,
    attendance_rate NUMERIC DEFAULT 100.00,
    leave_balance INTEGER DEFAULT 30,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABLE: employee_schedules
-- =====================================================
CREATE TABLE IF NOT EXISTS public.employee_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR NOT NULL,
    description TEXT,
    start_date_time TIMESTAMPTZ NOT NULL,
    end_date_time TIMESTAMPTZ NOT NULL,
    created_by_admin_id UUID REFERENCES public.my_users(id) NOT NULL,
    assigned_user_id UUID REFERENCES public.my_users(id) NOT NULL,
    actual_user_id UUID REFERENCES public.my_users(id),
    department VARCHAR NOT NULL,
    location VARCHAR NOT NULL,
    latitude NUMERIC,
    longitude NUMERIC,
    status VARCHAR DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled', 'reassigned')),
    requirements JSONB,
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    tags TEXT[],
    custom_fields JSONB,
    assignment_history JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    max_participants INTEGER,
    min_participants INTEGER DEFAULT 1,
    current_participants INTEGER DEFAULT 0,
    is_multi_user BOOLEAN DEFAULT false
);

-- =====================================================
-- TABLE: attendance
-- =====================================================
CREATE TABLE IF NOT EXISTS public.attendance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.my_users(id),
    schedule_id UUID REFERENCES public.employee_schedules(id),
    date DATE NOT NULL,
    check_in_time TIMESTAMPTZ,
    check_out_time TIMESTAMPTZ,
    check_in_location_lat NUMERIC,
    check_in_location_lng NUMERIC,
    check_out_location_lat NUMERIC,
    check_out_location_lng NUMERIC,
    check_in_address TEXT,
    check_out_address TEXT,
    location TEXT,
    latitude NUMERIC,
    longitude NUMERIC,
    break_start_time TIMESTAMPTZ,
    break_end_time TIMESTAMPTZ,
    total_work_hours NUMERIC DEFAULT 0.00,
    total_break_hours NUMERIC DEFAULT 0.00,
    net_work_hours NUMERIC DEFAULT 0.00,
    overtime_hours NUMERIC DEFAULT 0.00,
    total_hours NUMERIC DEFAULT 0,
    break_duration NUMERIC DEFAULT 0,
    expected_hours NUMERIC DEFAULT 8.00,
    status VARCHAR DEFAULT 'pending' CHECK (status IN ('pending', 'pending_checkout', 'completed', 'granted', 'not_granted', 'cancelled', 'unusual', 'appealed', 'rejected', 'approved')),
    reviewed_by UUID REFERENCES public.my_users(id),
    reviewed_at TIMESTAMPTZ,
    admin_notes TEXT,
    review_reason VARCHAR,
    payment_status VARCHAR DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid', 'processing', 'paid', 'held', 'cancelled')),
    calculated_amount NUMERIC DEFAULT 0.00,
    overtime_amount NUMERIC DEFAULT 0.00,
    total_amount NUMERIC DEFAULT 0.00,
    paid_amount NUMERIC DEFAULT 0.00,
    payment_date TIMESTAMPTZ,
    payment_reference VARCHAR,
    work_type VARCHAR DEFAULT 'regular' CHECK (work_type IN ('regular', 'overtime', 'holiday', 'night_shift', 'weekend')),
    shift_type VARCHAR,
    employee_notes TEXT,
    device_info JSONB,
    ip_address INET,
    is_late BOOLEAN DEFAULT false,
    is_early_departure BOOLEAN DEFAULT false,
    break_exceeded BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABLE: schedule_assignments
-- =====================================================
CREATE TABLE IF NOT EXISTS public.schedule_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id UUID REFERENCES public.employee_schedules(id) NOT NULL,
    user_id UUID REFERENCES public.my_users(id) NOT NULL,
    assigned_at TIMESTAMPTZ DEFAULT NOW(),
    assigned_by_admin_id UUID REFERENCES public.my_users(id),
    status VARCHAR DEFAULT 'active' CHECK (status IN ('active', 'removed', 'completed', 'reassigned')),
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABLE: schedule_exchange_requests
-- =====================================================
CREATE TABLE IF NOT EXISTS public.schedule_exchange_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id UUID REFERENCES public.employee_schedules(id) NOT NULL,
    requester_user_id UUID REFERENCES public.my_users(id) NOT NULL,
    requested_user_id UUID REFERENCES public.my_users(id) NOT NULL,
    request_reason TEXT,
    request_notes TEXT,
    request_type VARCHAR DEFAULT 'exchange' CHECK (request_type IN ('exchange', 'swap', 'coverage')),
    status VARCHAR DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled', 'expired')),
    reviewed_by_admin_id UUID REFERENCES public.my_users(id),
    reviewed_at TIMESTAMPTZ,
    admin_notes TEXT,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '7 days'),
    request_metadata JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true
);

-- =====================================================
-- TABLE: daily_employee_summary
-- =====================================================
CREATE TABLE IF NOT EXISTS public.daily_employee_summary (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id UUID REFERENCES public.my_users(id),
    date DATE NOT NULL,
    total_work_hours NUMERIC DEFAULT 0.00,
    overtime_hours NUMERIC DEFAULT 0.00,
    break_hours NUMERIC DEFAULT 0.00,
    net_work_hours NUMERIC DEFAULT 0.00,
    granted_hours NUMERIC DEFAULT 0.00,
    pending_hours NUMERIC DEFAULT 0.00,
    not_granted_hours NUMERIC DEFAULT 0.00,
    granted_records INTEGER DEFAULT 0,
    pending_records INTEGER DEFAULT 0,
    not_granted_records INTEGER DEFAULT 0,
    cancelled_records INTEGER DEFAULT 0,
    granted_amount NUMERIC DEFAULT 0.00,
    pending_amount NUMERIC DEFAULT 0.00,
    not_granted_amount NUMERIC DEFAULT 0.00,
    total_amount NUMERIC DEFAULT 0.00,
    paid_amount NUMERIC DEFAULT 0.00,
    unpaid_amount NUMERIC DEFAULT 0.00,
    attendance_rate NUMERIC DEFAULT 0.00,
    punctuality_score NUMERIC DEFAULT 0.00,
    overtime_percentage NUMERIC DEFAULT 0.00,
    break_compliance NUMERIC DEFAULT 0.00,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    calculation_status VARCHAR DEFAULT 'pending',
    UNIQUE(employee_id, date)
);

-- =====================================================
-- TABLE: monthly_employee_summary
-- =====================================================
CREATE TABLE IF NOT EXISTS public.monthly_employee_summary (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id UUID REFERENCES public.my_users(id),
    year INTEGER NOT NULL,
    month INTEGER NOT NULL,
    total_work_hours NUMERIC DEFAULT 0.00,
    total_overtime_hours NUMERIC DEFAULT 0.00,
    total_granted_hours NUMERIC DEFAULT 0.00,
    total_pending_hours NUMERIC DEFAULT 0.00,
    total_not_granted_hours NUMERIC DEFAULT 0.00,
    gross_earnings NUMERIC DEFAULT 0.00,
    overtime_earnings NUMERIC DEFAULT 0.00,
    granted_earnings NUMERIC DEFAULT 0.00,
    pending_earnings NUMERIC DEFAULT 0.00,
    not_granted_earnings NUMERIC DEFAULT 0.00,
    total_paid NUMERIC DEFAULT 0.00,
    total_unpaid NUMERIC DEFAULT 0.00,
    days_worked INTEGER DEFAULT 0,
    days_pending INTEGER DEFAULT 0,
    days_not_granted INTEGER DEFAULT 0,
    expected_work_days INTEGER DEFAULT 0,
    avg_daily_hours NUMERIC DEFAULT 0.00,
    attendance_rate NUMERIC DEFAULT 0.00,
    approval_rate NUMERIC DEFAULT 0.00,
    punctuality_rate NUMERIC DEFAULT 0.00,
    total_granted_records INTEGER DEFAULT 0,
    total_pending_records INTEGER DEFAULT 0,
    total_not_granted_records INTEGER DEFAULT 0,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(employee_id, year, month)
);

-- =====================================================
-- ENABLE RLS ON ALL TABLES
-- =====================================================
ALTER TABLE public.my_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schedule_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schedule_exchange_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_employee_summary ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_employee_summary ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- RLS POLICIES: my_users
-- =====================================================
CREATE POLICY "Authenticated users can view all users"
ON public.my_users FOR SELECT
USING (auth.role() = 'authenticated');

CREATE POLICY "Users can update own profile"
ON public.my_users FOR UPDATE
USING (auth.uid() = id);

CREATE POLICY "Users can delete own profile"
ON public.my_users FOR DELETE
USING (auth.uid() = id);

CREATE POLICY "Authenticated users can insert own profile"
ON public.my_users FOR INSERT
WITH CHECK (auth.uid() = id AND auth.role() = 'authenticated');

CREATE POLICY "Service role full access"
ON public.my_users FOR ALL
USING (auth.role() = 'service_role');

-- =====================================================
-- RLS POLICIES: employee_schedules
-- =====================================================
CREATE POLICY "Authenticated users can view schedules"
ON public.employee_schedules FOR SELECT
USING (auth.role() = 'authenticated');

CREATE POLICY "Admins can insert schedules"
ON public.employee_schedules FOR INSERT
WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can update assigned schedules"
ON public.employee_schedules FOR UPDATE
USING (assigned_user_id = auth.uid() OR actual_user_id = auth.uid());

CREATE POLICY "Service role full access"
ON public.employee_schedules FOR ALL
USING (auth.role() = 'service_role');

-- =====================================================
-- RLS POLICIES: attendance
-- =====================================================
CREATE POLICY "Users can view own attendance"
ON public.attendance FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all attendance"
ON public.attendance FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.user_role IN ('admin', 'ceo')
    )
);

CREATE POLICY "Service role full access attendance"
ON public.attendance FOR ALL
USING (auth.role() = 'service_role');

-- =====================================================
-- RLS POLICIES: schedule_assignments
-- =====================================================
CREATE POLICY "Users can view their own schedule assignments"
ON public.schedule_assignments FOR SELECT
USING (user_id = auth.uid() OR assigned_by_admin_id = auth.uid());

CREATE POLICY "Admins can manage schedule assignments"
ON public.schedule_assignments FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.user_role IN ('admin', 'ceo', 'manager')
    )
);

-- =====================================================
-- RLS POLICIES: schedule_exchange_requests
-- =====================================================
CREATE POLICY "Users can view their own exchange requests"
ON public.schedule_exchange_requests FOR SELECT
USING (
    requester_user_id = auth.uid() OR
    requested_user_id = auth.uid() OR
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.user_role IN ('admin', 'ceo', 'manager')
        AND my_users.is_active = true
    )
);

CREATE POLICY "Users can create exchange requests"
ON public.schedule_exchange_requests FOR INSERT
WITH CHECK (
    requester_user_id = auth.uid() AND
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.is_active = true
    )
);

CREATE POLICY "Users can cancel their own requests"
ON public.schedule_exchange_requests FOR UPDATE
USING (requester_user_id = auth.uid() AND status = 'pending');

CREATE POLICY "Admins can update exchange requests"
ON public.schedule_exchange_requests FOR UPDATE
USING (
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.user_role IN ('admin', 'ceo', 'manager')
        AND my_users.is_active = true
    )
);

-- =====================================================
-- RLS POLICIES: daily_employee_summary
-- =====================================================
CREATE POLICY "Users can view own summaries"
ON public.daily_employee_summary FOR SELECT
USING (
    employee_id = auth.uid() OR
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.user_role IN ('admin', 'ceo')
    )
);

CREATE POLICY "Service role full access summaries"
ON public.daily_employee_summary FOR ALL
USING (auth.role() = 'service_role');

-- =====================================================
-- RLS POLICIES: monthly_employee_summary
-- =====================================================
CREATE POLICY "Users can view own summaries"
ON public.monthly_employee_summary FOR SELECT
USING (
    employee_id = auth.uid() OR
    EXISTS (
        SELECT 1 FROM public.my_users
        WHERE my_users.id = auth.uid()
        AND my_users.user_role IN ('admin', 'ceo')
    )
);

-- =====================================================
-- INDICES FOR PERFORMANCE
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_attendance_user_id ON public.attendance(user_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON public.attendance(date);
CREATE INDEX IF NOT EXISTS idx_attendance_status ON public.attendance(status);
CREATE INDEX IF NOT EXISTS idx_attendance_schedule_id ON public.attendance(schedule_id);
CREATE INDEX IF NOT EXISTS idx_schedules_assigned_user ON public.employee_schedules(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_schedules_start_date ON public.employee_schedules(start_date_time);
CREATE INDEX IF NOT EXISTS idx_schedule_assignments_user ON public.schedule_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_schedule_assignments_schedule ON public.schedule_assignments(schedule_id);

-- =====================================================
-- RE-ENABLE NORMAL OPERATIONS
-- =====================================================
SET session_replication_role = DEFAULT;

-- =====================================================
-- DATA EXPORT NOTES
-- =====================================================
-- To export data from existing database, run these queries:
-- 
-- COPY (SELECT * FROM my_users) TO '/tmp/my_users.csv' WITH CSV HEADER;
-- COPY (SELECT * FROM employee_schedules) TO '/tmp/employee_schedules.csv' WITH CSV HEADER;
-- COPY (SELECT * FROM attendance) TO '/tmp/attendance.csv' WITH CSV HEADER;
-- COPY (SELECT * FROM schedule_assignments) TO '/tmp/schedule_assignments.csv' WITH CSV HEADER;
-- COPY (SELECT * FROM schedule_exchange_requests) TO '/tmp/schedule_exchange_requests.csv' WITH CSV HEADER;
-- COPY (SELECT * FROM daily_employee_summary) TO '/tmp/daily_employee_summary.csv' WITH CSV HEADER;
-- COPY (SELECT * FROM monthly_employee_summary) TO '/tmp/monthly_employee_summary.csv' WITH CSV HEADER;
--
-- Note: The above COPY commands require superuser access. 
-- For Supabase, use the dashboard's export functionality or use the data dump below.
--
-- =====================================================

-- =====================================================
-- CURRENT DATABASE STATISTICS
-- =====================================================
-- Table                       | Row Count
-- ----------------------------|----------
-- schedule_assignments        | 17
-- employee_schedules          | 16
-- attendance                  | 8
-- schedule_exchange_requests  | 7
-- daily_employee_summary      | 6
-- my_users                    | 5
-- monthly_employee_summary    | 3
-- =====================================================

-- =====================================================
-- END OF SCHEMA DUMP
-- Next step: Export data using Supabase dashboard
-- or use the JSON export script provided separately
-- =====================================================

