# Supabase Database Restoration Guide

## 📦 Backup Files Created

1. **`supabase_backup_dump.sql`** - Complete schema with RLS policies
2. **`supabase_data_export.json`** - Data export metadata and instructions
3. **`sql/` directory** - All function definitions

## 🔄 How to Restore Your Database

### Method 1: Full Restoration (Recommended)

#### Step 1: Create New Supabase Project
1. Go to https://supabase.com/dashboard
2. Click "New Project"
3. Choose organization and region (preferably `ap-south-1` to match original)
4. Set database password
5. Wait for project to be ready

#### Step 2: Restore Schema
1. Open SQL Editor in new project
2. Copy entire content of `supabase_backup_dump.sql`
3. Paste and execute
4. This creates all tables, RLS policies, and indices

#### Step 3: Export Data from Old Database
In your current Supabase project (epigntookxmheaoreqjw):

**Option A: Using Supabase Dashboard**
1. Go to Table Editor
2. For each table, click the table → Export → CSV
3. Download all CSVs:
   - my_users.csv
   - employee_schedules.csv
   - attendance.csv
   - schedule_assignments.csv
   - schedule_exchange_requests.csv
   - daily_employee_summary.csv
   - monthly_employee_summary.csv

**Option B: Using SQL Export**
Run these queries in SQL Editor and copy results:

```sql
-- Export my_users
SELECT json_agg(t) FROM my_users t;

-- Export employee_schedules  
SELECT json_agg(t) FROM employee_schedules t;

-- Export attendance
SELECT json_agg(t) FROM attendance t;

-- Export schedule_assignments
SELECT json_agg(t) FROM schedule_assignments t;

-- Export schedule_exchange_requests
SELECT json_agg(t) FROM schedule_exchange_requests t;

-- Export daily_employee_summary
SELECT json_agg(t) FROM daily_employee_summary t;

-- Export monthly_employee_summary
SELECT json_agg(t) FROM monthly_employee_summary t;
```

#### Step 4: Import Data to New Database

**Option A: Using Dashboard (for CSV files)**
1. In new project, go to Table Editor
2. Select table
3. Click Import → Upload CSV
4. Map columns and import

**Option B: Using SQL (for JSON)**
For each table, use INSERT statements. Example:

```sql
-- Disable triggers during import
SET session_replication_role = replica;

-- Import my_users
INSERT INTO my_users 
SELECT * FROM json_populate_recordset(null::my_users, '[
  -- paste your JSON array here
]');

-- Import employee_schedules
INSERT INTO employee_schedules 
SELECT * FROM json_populate_recordset(null::employee_schedules, '[
  -- paste your JSON array here
]');

-- Repeat for all tables...

-- Re-enable triggers
SET session_replication_role = DEFAULT;
```

#### Step 5: Restore Functions
Copy all SQL files from `sql/` directory and run them in new project:

1. `sql/attendance_functions.sql`
2. `sql/attendance_history_rpc.sql`
3. `sql/comprehensive_attendance_system.sql`
4. `sql/multi_user_schedule_system.sql`
5. `sql/schedule_exchange_functions.sql`
6. Any other SQL files you've created

#### Step 6: Verify Restoration

Run these verification queries:

```sql
-- Check table counts
SELECT 
  'my_users' as table_name, 
  COUNT(*) as count 
FROM my_users
UNION ALL
SELECT 'employee_schedules', COUNT(*) FROM employee_schedules
UNION ALL
SELECT 'attendance', COUNT(*) FROM attendance
UNION ALL
SELECT 'schedule_assignments', COUNT(*) FROM schedule_assignments
UNION ALL
SELECT 'schedule_exchange_requests', COUNT(*) FROM schedule_exchange_requests
UNION ALL
SELECT 'daily_employee_summary', COUNT(*) FROM daily_employee_summary
UNION ALL
SELECT 'monthly_employee_summary', COUNT(*) FROM monthly_employee_summary;

-- Expected results:
-- my_users: 5
-- employee_schedules: 16
-- attendance: 8
-- schedule_assignments: 17
-- schedule_exchange_requests: 7
-- daily_employee_summary: 6
-- monthly_employee_summary: 3

-- Check RLS policies
SELECT 
  tablename, 
  policyname 
FROM pg_policies 
WHERE schemaname = 'public' 
ORDER BY tablename, policyname;

-- Check functions
SELECT 
  proname as function_name
FROM pg_proc p
LEFT JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
  AND proname LIKE '%attendance%'
ORDER BY proname;
```

#### Step 7: Update Flutter App Configuration

In your Flutter app, update Supabase credentials:

```dart
// lib/main.dart or wherever you initialize Supabase
await Supabase.initialize(
  url: 'YOUR_NEW_PROJECT_URL',
  anonKey: 'YOUR_NEW_ANON_KEY',
);
```

Get new credentials from:
- Project Settings → API → Project URL
- Project Settings → API → Project API keys → anon public

### Method 2: Quick Clone (Using Supabase CLI)

If you have Supabase CLI installed:

```bash
# Link to old project
supabase link --project-ref epigntookxmheaoreqjw

# Generate migration from existing database
supabase db pull

# This creates a migration file with all schema

# Create new project and push
supabase link --project-ref NEW_PROJECT_REF
supabase db push
```

**Note:** This method only copies schema, not data. You'll still need to export/import data manually.

## 🚨 Important Notes

### Before Restoration:
- [ ] Save all environment variables
- [ ] Note down all API keys
- [ ] Document any custom configurations
- [ ] Backup any storage bucket files separately

### During Restoration:
- [ ] Disable RLS temporarily (already done in dump file)
- [ ] Import in correct order (users first, then schedules, then attendance)
- [ ] Verify foreign key relationships

### After Restoration:
- [ ] Test all RLS policies
- [ ] Verify all functions work
- [ ] Test application authentication
- [ ] Check data integrity
- [ ] Update DNS/webhooks if needed

## 📊 Data Size Information

Current database statistics:
- **Total Records**: 62
- **Total Tables**: 7
- **Total RLS Policies**: 21
- **Total Functions**: 39
- **Database Size**: ~5-10 MB (estimated)

## 🔐 Security Checklist

After restoration:
- [ ] All RLS policies are active
- [ ] Service role key is secure
- [ ] Anon key is rotated if compromised
- [ ] Database password is strong
- [ ] No sensitive data in logs
- [ ] Auth providers reconfigured

## 🆘 Troubleshooting

### Error: "relation does not exist"
**Solution**: Run schema dump first before importing data

### Error: "violates foreign key constraint"
**Solution**: Import tables in this order:
1. my_users
2. employee_schedules
3. attendance
4. schedule_assignments
5. schedule_exchange_requests
6. daily_employee_summary
7. monthly_employee_summary

### Error: "permission denied for table"
**Solution**: Ensure you're using service role key for restoration

### Error: "duplicate key value"
**Solution**: Clear target table before importing:
```sql
TRUNCATE TABLE table_name CASCADE;
```

## 📞 Support

If you encounter issues:
1. Check Supabase documentation
2. Review error logs in dashboard
3. Verify SQL syntax
4. Test with small data subset first

## 🎯 Success Criteria

✅ All 7 tables created
✅ All 21 RLS policies active
✅ All 39 functions working
✅ Data counts match original
✅ Flutter app connects successfully
✅ Authentication works
✅ All features functional

---

**Backup Date:** October 2, 2025  
**Original Project ID:** epigntookxmheaoreqjw  
**Database Version:** PostgreSQL 17.4.1.074

